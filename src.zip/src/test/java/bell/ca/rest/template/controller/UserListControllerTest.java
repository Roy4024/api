package bell.ca.rest.template.controller;

import bell.ca.rest.template.dto.UserRequestDTO;
import bell.ca.rest.template.service.UserListService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.*;

class UserListControllerTest {
    @Mock
    UserListService userService;
    @InjectMocks
    UserListController userListController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testHealthCheck() {
        ResponseEntity<String> result = userListController.healthCheck();
        Assertions.assertEquals(HttpStatus.OK, result.getStatusCode());
        Assertions.assertEquals("{\"status\": \"ok\"}", result.getBody());
        Assertions.assertEquals("true", result.getHeaders().getFirst("X-Health-Check"));

    }

    @Test
    void testGetUserList() throws Exception {
        // Mock the service response
        when(userService.getUserList(any(UserRequestDTO.class), anyString(), anyString()))
                .thenReturn(new UserListService.ServiceResponse("responseBody", HttpStatus.CONTINUE));

        // Call the controller
        ResponseEntity<String> result = userListController.getUserList("apiKey", new UserRequestDTO());

        // Assert the values
        Assertions.assertEquals("responseBody", result.getBody());
        Assertions.assertEquals(HttpStatus.CONTINUE, result.getStatusCode());
    }

}

//Generated with love by TestMe :) Please raise issues & feature requests at: https://weirddev.com/forum#!/testme