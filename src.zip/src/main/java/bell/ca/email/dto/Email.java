package bell.ca.email.dto;

import java.util.List;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author eswarar.siva
 * Model for email body
 *
 */
@Data
@NoArgsConstructor
public class Email {
	
	private String project;
	private String action;
	private String description;
	private String language;
	private List<Receiver> receiver;
	private String sourceSystem;
	private String storeToDRSFlag;
	private String subject;	
	private TemplateDetails templateDetails;
	/**
	 * @param project2
	 */


	
	


}