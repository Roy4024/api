/**
 * 
 */
package bell.ca.email.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author eswarar.siva
 *
 */
@Data
@AllArgsConstructor
public class TemplateData {

	private String name;
	private String value;


	
	
}
