/**
 * 
 */
package bell.ca.email.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author eswarar.siva
 *
 */
@Data
@AllArgsConstructor
public class TemplateDetails {
	
	private List<TemplateData> templateData;
	private String templateName;

}
