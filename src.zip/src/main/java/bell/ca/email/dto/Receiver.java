/**
 * 
 */
package bell.ca.email.dto;

import lombok.Data;

/**
 * @author eswarar.siva
 *
 */
@Data
public class Receiver {

	private String email;
	private String type;
}
