/**
 * 
 */
package bell.ca.template.util;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Data;


/**
 * @author Eswarar.Siva
 */
@Configuration
@ConfigurationProperties(prefix="email")
@Data
public class EmailConfig {
	
	private String project;
	private String action;
	private String description;
	private String language;
	private String emailTo;
	private String sourceSystem;
	private String storeToDRSFlag;
	private String subject;	
	private String templateName;
	private String apiKey;

}
