/**
 * 
 */
package bell.ca.template.util;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.SSLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

//import bell.ca.rest.template.util.EmailConfig;

import bell.ca.email.dto.Email;
import bell.ca.email.dto.Receiver;
import bell.ca.email.dto.TemplateData;
import bell.ca.email.dto.TemplateDetails;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;


/**
 * @author Eswarar.Siva
 * This service sends error mail
 */




@Slf4j
@Service
public class EmailService {
	
	

	
	@Autowired
	private EmailConfig emailConfig;


	
	@Value("${email.url}") 
	private String baseUrl;

	

//	public void sendErrorMail(Exception ex,Boolean emailFlag,String xCorrelationID,String ErrorLayer) {
//
//		if(emailFlag){
//			
//			sendMail(ex.getMessage(),xCorrelationID,ErrorLayer);
//		}
//
//	}
//	


	public void sendMail(String errorMessage,String requestId,String ErrorLayer) throws SSLException {

		try {

			
			Email email = new Email();
			email.setProject(emailConfig.getProject());
			email.setAction(emailConfig.getAction());
			email.setDescription(null);
			email.setLanguage(emailConfig.getLanguage());
			Receiver receiver = new Receiver();
			receiver.setEmail(emailConfig.getEmailTo());
			receiver.setType("to");
			List<Receiver> receiverList = new ArrayList<>();
			receiverList.add(receiver);
			email.setReceiver(receiverList);
			email.setSourceSystem(emailConfig.getSourceSystem());
			email.setStoreToDRSFlag(emailConfig.getStoreToDRSFlag());
			email.setSubject(emailConfig.getSubject());

			List<TemplateData> templateData = new ArrayList<>();

				
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			templateData.add(new TemplateData("Error Layer", ErrorLayer));
			templateData.add(new TemplateData("requestId", requestId));
			templateData.add(new TemplateData("TimeStamp",offsetdatetime.toString()));
			templateData.add(new TemplateData("Error Message", errorMessage));

			TemplateDetails templateDetails = new TemplateDetails(templateData,emailConfig.getTemplateName());
			email.setTemplateDetails(templateDetails);
			
			
			SslContext sslContext = SslContextBuilder.forClient()
	                .trustManager(InsecureTrustManagerFactory.INSTANCE)
	                .build();

	        // Create an HttpClient with the SslContext
	        HttpClient httpClient = HttpClient.create().secure(ssl -> ssl.sslContext(sslContext));

	        // Build the WebClient using the custom HttpClient
	        WebClient webClient = WebClient.builder()
	                .clientConnector(new ReactorClientHttpConnector(httpClient))
	                .build();
			

			Mono<String> emailResponse = webClient.post()
					.uri(baseUrl)
					.contentType(MediaType.APPLICATION_JSON)
					.bodyValue(email)
					.header("Api_key", emailConfig.getApiKey())
					.retrieve()
					.bodyToMono(String.class);		

			emailResponse.subscribe(response -> log.debug("Email response - {}",response));



		}
		catch (WebClientResponseException e) {
			log.error("ERROR::SpringBoot::(ArcUsageInfo Kafka Consumer) Email Service Invoker Exception::-::{}::ARC::Fail::-::-::-:", requestId, e);
		}



	}

}
