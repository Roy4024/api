package bell.ca.rest.template.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManagerFactory;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.time.Duration;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient webClient() throws SSLException {
        HttpClient httpClient = HttpClient.create()
                .secure(sslContextSpec -> {
                    try {
                        sslContextSpec.sslContext(secureSslContext());
                    } catch (SSLException e) {
                        throw new RuntimeException("Failed to initialize WebClient due to SSL context error", e);
                    }
                })
                .responseTimeout(Duration.ofSeconds(60));

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(20 * 1024 * 1024))
                .baseUrl("https://idd-dev-spanner-crun.int.bell.ca/idd/hierarchy")
                .build();
    }

    private SslContext secureSslContext() throws SSLException {
        try {
            KeyStore trustStore = KeyStore.getInstance("JKS");
            try (FileInputStream trustStream = new FileInputStream("certs/truststore.jks")) {
                trustStore.load(trustStream, null);
            }
            TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            trustManagerFactory.init(trustStore);
            return SslContextBuilder.forClient()
                    .trustManager(trustManagerFactory)
                    .build();
        } catch (Exception e) {
            throw new SSLException("Failed to create secure SSL context", e);
        }
    }
}