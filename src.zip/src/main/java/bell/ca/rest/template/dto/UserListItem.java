package bell.ca.rest.template.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class UserListItem {

    @JsonProperty("USER_ID")
    private Long userId;

    @JsonProperty("USER_LOGIN")
    private String userLogin;

    @JsonProperty("USER_FULL_NAME")
    private String userFullName;

    @JsonProperty("TOTAL_NODE_COUNT")
    private Integer totalNodeCount;

    @JsonProperty("VISIBLE_NODE_COUNT")
    private Integer visibleNodeCount;
}