package bell.ca.rest.template.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.http.HttpHeaders;

import java.util.List;

@Data
public class ExternalApiResponse {

    @JsonProperty("REQUESTID")
    private String requestId;

    @JsonProperty("ORGANIZATION_NUM")
    private Integer organizationNum;

    @JsonProperty("USERS")
    private List<UserListItem> users;

    private HttpHeaders headers;

    private String code;
    private String errorReason;
    private String status;
}