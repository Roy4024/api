package bell.ca.rest.template.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class UserItem {

    @JsonProperty("userId")
    private Long userId;

    @JsonProperty("fullName")
    private String fullName;

    @JsonProperty("totalNodeCount")
    private Integer totalNodeCount;

    @JsonProperty("visibleNodeCount")
    private Integer visibleNodeCount;
}