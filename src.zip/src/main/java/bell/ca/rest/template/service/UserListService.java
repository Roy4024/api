package bell.ca.rest.template.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import bell.ca.rest.template.dto.ErrorResponse;
import bell.ca.rest.template.dto.ExternalApiResponse;
import bell.ca.rest.template.dto.ExternalUserListRequestDTO;
import bell.ca.rest.template.dto.UserItem;
import bell.ca.rest.template.dto.UserRequestDTO;
import bell.ca.rest.template.dto.UserListItem;
import bell.ca.rest.template.dto.UserResponseDTO;
import bell.ca.template.util.EmailService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import java.util.List;
import java.util.ArrayList;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserListService {

    private final ObjectMapper objectMapper;
    private final EmailService emailService;
    private final WebClient webClient;

    @Value("${api.key}")
    private String validApiKey;

    @Value("${external.api.url}")
    private String externalApiUrl;

    @Value("${token.api.url}")
    private String tokenApiUrl;

    @Value("${token.api.key}")
    private String tokenApiKey;

    @Value("${idd.default.extract.size}")
    private int iddDefaultExtractSize;

    @Value("${webflux.message.size:16777216600}")
    private int messageSize;

    @Value("${webflux.connection.timeout:300000}")
    private int connectionTimeout;

    @Value("${webflux.response.timeout:1500}")
    private int responseTimeout;

    @Value("${webflux.read.timeout:300}")
    private int readTimeout;

    @Value("${webflux.write.timeout:300}")
    private int writeTimeout;

    @Value("${sslsample.truststore.type:JKS}")
    private String trustStoreType;

    @Value("${sslsample.keystore.path}")
    private String keyStorePath;

    @Value("${sslsample.keystore.password}")
    private String keyStorePassword;

    @Value("${webclient.builderType:userListService}")
    private String builderType;

    @Value("${webclient.maxConnections:500}")
    private int maxConnections;

    @Value("${webclient.maxLifeTime:3600}")
    private int maxLifeTime;

    @Value("${webclient.maxIdleTime:1800}")
    private int maxIdleTime;

    @Value("${webclient.pendingAcquireTimeout:60}")
    private int pendingAcquireTimeout;

    @Value("${webclient.evictInBackground:120}")
    private int evictInBackground;

    @Value("${webclient.bypassHostnameVerification:false}")
    private boolean bypassHostnameVerification;

    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    // ServiceResponse class to encapsulate response body and HTTP status
    public static class ServiceResponse {
        private final String responseBody;
        private final HttpStatus status;

        public ServiceResponse(String responseBody, HttpStatus status) {
            this.responseBody = responseBody;
            this.status = status;
        }

        public String getResponseBody() {
            return responseBody;
        }

        public HttpStatus getStatus() {
            return status;
        }
    }

    private void logToKibana(String logType, String requestId, String status, String message) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        String logMessage = String.format("[%s] %s %s [ID:%s] %s :: %s",
                timestamp,
                status.equals("ERROR") ? "❌" : status.equals("WARN") ? "⚠️" : status.equals("SUCCESS") ? "✅" : "🚀",
                logType,
                requestId,
                status,
                message);
        log.info(logMessage);
    }

    public boolean validateApi(String apiKey, String rqid) {
        long startTime = System.nanoTime();
        String requestId = rqid;
        logToKibana("API Validation", requestId, "INFO", "[UserListService.validateApi] Starting API key validation");
        if (apiKey == null || apiKey.isEmpty()) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("API Validation", requestId, "ERROR", "[UserListService.validateApi] Missing or empty API key in " + durationMs + " ms");
            try {
                emailService.sendMail("API Key Validation Failure", requestId, "Missing or empty API key");
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.validateApi] Failed to send API key validation error email: " + mailEx.getMessage());
            }
            return false;
        }
        if (!apiKey.equals(validApiKey)) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("API Validation", requestId, "ERROR", "[UserListService.validateApi] Invalid API key in " + durationMs + " ms");
            try {
                emailService.sendMail("API Key Validation Failure", requestId, "Invalid API key");
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.validateApi] Failed to send API key validation error email: " + mailEx.getMessage());
            }
            return false;
        }
        long durationMs = (System.nanoTime() - startTime) / 1_000_000;
        logToKibana("API Validation", requestId, "SUCCESS", "[UserListService.validateApi] API key validated in " + durationMs + " ms");
        return true;
    }

    public ServiceResponse getUserList(UserRequestDTO request, String apiKey, String requestId) throws Exception {
        long startTime = System.nanoTime();
        long totalApiTimeNs = 0;
        logToKibana("UserList Request", requestId, "INFO", "[UserListService.getUserList] Starting user list request processing");

        // Validate request body
        if (request == null) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Request Validation", requestId, "ERROR", "[UserListService.getUserList] Request is null in " + durationMs + " ms");
            try {
                emailService.sendMail("UserList Request Failure", requestId, "Request is null");
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.getUserList] Failed to send request validation error email: " + mailEx.getMessage());
            }
            return new ServiceResponse(formatErrorResponse("400", requestId, "Request cannot be null", "Failure"), HttpStatus.BAD_REQUEST);
        }

        if (requestId == null || requestId.isEmpty()) {
            requestId = UUID.randomUUID().toString();
            logToKibana("Request ID Generation", requestId, "WARN", "[UserListService.getUserList] Generated new requestId: " + requestId);
        }

        // Validate API key
        if (!validateApi(apiKey, requestId)) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            return new ServiceResponse(formatErrorResponse("401", requestId, "Invalid or missing API key", "Failure"), HttpStatus.UNAUTHORIZED);
        }

        // Extract pageNo and pageSize for offset calculation
        int offset = 0;
        logToKibana("Pagination Setup", requestId, "INFO", "[UserListService.getUserList] Offset: " + offset + ", Limit: " + iddDefaultExtractSize);

        String token;
        try {
            token = fetchTokenFromExternalApi(requestId);
        } catch (Exception e) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Token Fetch", requestId, "ERROR", "[UserListService.getUserList] Failed to fetch token in " + durationMs + " ms");
            try {
                emailService.sendMail("Token Fetch Failure", requestId, "Failed to fetch token: " + e.getMessage());
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.getUserList] Failed to send token fetch error email: " + mailEx.getMessage());
            }
            return new ServiceResponse(formatErrorResponse("500", requestId, "Failed to fetch token", "Failure"), HttpStatus.INTERNAL_SERVER_ERROR);
        }

        if (token == null || token.isEmpty()) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Token Fetch", requestId, "ERROR", "[UserListService.getUserList] Token is null or empty in " + durationMs + " ms");
            try {
                emailService.sendMail("Token Fetch Failure", requestId, "Token is null or empty");
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.getUserList] Failed to send token fetch error email: " + mailEx.getMessage());
            }
            return new ServiceResponse(formatErrorResponse("500", requestId, "Failed to fetch token", "Failure"), HttpStatus.INTERNAL_SERVER_ERROR);
        }
        logToKibana("Token Fetch", requestId, "SUCCESS", "[UserListService.getUserList] Token fetched successfully");

        ExternalUserListRequestDTO externalRequest;
        try {
            externalRequest = mapToExternalRequest(request);
            externalRequest.setOffset(offset);
            externalRequest.setLimit(String.valueOf(iddDefaultExtractSize));
            logToKibana("Request Mapping", requestId, "INFO", "[UserListService.getUserList] Mapped to external request: " + externalRequest);
        } catch (Exception e) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Request Mapping", requestId, "ERROR", "[UserListService.getUserList] Failed to map request in " + durationMs + " ms: " + e.getMessage());
            try {
                emailService.sendMail("Request Mapping Failure", requestId, "Failed to map request: " + e.getMessage());
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.getUserList] Failed to send request mapping error email: " + mailEx.getMessage());
            }
            return new ServiceResponse(formatErrorResponse("400", requestId, "Invalid request parameters", "Failure"), HttpStatus.BAD_REQUEST);
        }

        List<UserListItem> combinedUserList = new ArrayList<>();
        int totalCount = 0;

        long apiStartTime = System.nanoTime();
        ExternalApiResponse initialResponse;
        try {
            initialResponse = callExternalApi(token, externalRequest, requestId, true);
            totalApiTimeNs += (System.nanoTime() - apiStartTime);
        } catch (RuntimeException e) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            String errorMessage = e.getMessage();
            String[] parts = errorMessage.split("Status ");
            if (parts.length > 1) {
                String[] statusAndBody = parts[1].split(", Body: ");
                String statusCode = statusAndBody[0];
                String errorBody = statusAndBody.length > 1 ? statusAndBody[1] : "IDD Internal Server Error";
                String errorReason = extractErrorReason(errorBody, requestId);
                logToKibana("IDD API Error", requestId, "ERROR", "[UserListService.getUserList] Initial API call failed in " + durationMs + " ms: " + errorMessage);
                HttpStatus httpStatus = mapStatusCode(statusCode);
                return new ServiceResponse(formatErrorResponse(statusCode, requestId, errorReason, "Failure"), httpStatus);
            } else {
                logToKibana("IDD API Error", requestId, "ERROR", "[UserListService.getUserList] Unexpected initial API error in " + durationMs + " ms: " + errorMessage);
                return new ServiceResponse(formatErrorResponse("500", requestId, "IDD Internal Server Error", "Failure"), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }

        if (initialResponse != null && initialResponse.getUsers() != null) {
            combinedUserList.addAll(initialResponse.getUsers());
            totalCount = parseTotalCount(initialResponse.getHeaders());
            logToKibana("Initial API Response", requestId, "SUCCESS", "[UserListService.getUserList] Fetched " + combinedUserList.size() + " records, TotalCount: " + totalCount);
        } else {
            logToKibana("Initial API Response", requestId, "WARN", "[UserListService.getUserList] No data in initial response");
        }

        if (totalCount <= offset) {
            logToKibana("Pagination Check", requestId, "INFO", "[UserListService.getUserList] TotalCount (" + totalCount + ") <= Offset (" + offset + "), returning empty user list");
            String response = formatUserResponse(combinedUserList, requestId);
            long totalDurationMs = (System.nanoTime() - startTime) / 1_000_000;
            double totalApiTimeSec = totalApiTimeNs / 1_000_000_000.0;
            logToKibana("UserList Request", requestId, "SUCCESS", "[UserListService.getUserList] User list request processed in " + totalDurationMs + " ms, Total IDD API time: " + String.format("%.3f", totalApiTimeSec) + " sec, Total API calls: 1");
            return new ServiceResponse(response, HttpStatus.OK);
        }

        int fetchedRecords = combinedUserList.size();
        int callCount = 1;
        while (fetchedRecords < totalCount && offset < totalCount) {
            offset += iddDefaultExtractSize;
            externalRequest.setOffset(offset);
            externalRequest.setLimit(String.valueOf(iddDefaultExtractSize));
            logToKibana("Subsequent API Call", requestId, "INFO", "[UserListService.getUserList] Fetching batch " + (callCount + 1) + ", Offset: " + offset);

            if (offset >= totalCount) {
                logToKibana("Pagination Check", requestId, "INFO", "[UserListService.getUserList] Offset (" + offset + ") >= TotalCount (" + totalCount + "), stopping further API calls");
                break;
            }

            apiStartTime = System.nanoTime();
            ExternalApiResponse subsequentResponse;
            try {
                subsequentResponse = callExternalApi(token, externalRequest, requestId, false);
                totalApiTimeNs += (System.nanoTime() - apiStartTime);
            } catch (RuntimeException e) {
                long durationMs = (System.nanoTime() - startTime) / 1_000_000;
                String errorMessage = e.getMessage();
                String[] parts = errorMessage.split("Status ");
                if (parts.length > 1) {
                    String[] statusAndBody = parts[1].split(", Body: ");
                    String statusCode = statusAndBody[0];
                    String errorBody = statusAndBody.length > 1 ? statusAndBody[1] : "IDD Internal Server Error";
                    String errorReason = extractErrorReason(errorBody, requestId);
                    logToKibana("IDD API Error", requestId, "ERROR", "[UserListService.getUserList] Subsequent API call " + (callCount + 1) + " failed in " + durationMs + " ms: " + errorMessage);
                    HttpStatus httpStatus = mapStatusCode(statusCode);
                    return new ServiceResponse(formatErrorResponse(statusCode, requestId, errorReason, "Failure"), httpStatus);
                } else {
                    logToKibana("IDD API Error", requestId, "ERROR", "[UserListService.getUserList] Unexpected API error in call " + (callCount + 1) + " in " + durationMs + " ms: " + errorMessage);
                    return new ServiceResponse(formatErrorResponse("500", requestId, "IDD Internal Server Error", "Failure"), HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }

            if (subsequentResponse == null || subsequentResponse.getUsers() == null || subsequentResponse.getUsers().isEmpty()) {
                logToKibana("Subsequent API Response", requestId, "INFO", "[UserListService.getUserList] No more data in response for call " + (callCount + 1) + ", stopping further API calls");
                break;
            }

            combinedUserList.addAll(subsequentResponse.getUsers());
            fetchedRecords = combinedUserList.size();
            logToKibana("Subsequent API Response", requestId, "SUCCESS", "[UserListService.getUserList] Fetched " + fetchedRecords + "/" + totalCount + " records in call " + (callCount + 1));
            callCount++;
        }

        String response;
        try {
            response = formatUserResponse(combinedUserList, requestId);
        } catch (Exception e) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Response Formatting", requestId, "ERROR", "[UserListService.getUserList] Failed to format response in " + durationMs + " ms: " + e.getMessage());
            try {
                emailService.sendMail("Response Formatting Failure", requestId, "Failed to format response: " + e.getMessage());
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.getUserList] Failed to send response formatting error email: " + mailEx.getMessage());
            }
            return new ServiceResponse(formatErrorResponse("500", requestId, "IDD Internal Server Error", "Failure"), HttpStatus.INTERNAL_SERVER_ERROR);
        }

        double totalApiTimeSec = totalApiTimeNs / 1_000_000_000.0;
        long totalDurationMs = (System.nanoTime() - startTime) / 1_000_000;
        logToKibana("UserList Request", requestId, "SUCCESS", "[UserListService.getUserList] User list request processed in " + totalDurationMs + " ms, Total IDD API time: " + String.format("%.3f", totalApiTimeSec) + " sec, Total API calls: " + callCount);
        return new ServiceResponse(response, HttpStatus.OK);
    }

    private HttpStatus mapStatusCode(String statusCode) {
        switch (statusCode) {
            case "400":
                return HttpStatus.BAD_REQUEST;
            case "401":
                return HttpStatus.UNAUTHORIZED;
            case "422":
                return HttpStatus.UNPROCESSABLE_ENTITY;
            case "500":
                return HttpStatus.INTERNAL_SERVER_ERROR;
            default:
                return HttpStatus.INTERNAL_SERVER_ERROR;
        }
    }

    private String extractErrorReason(String errorBody, String requestId) {
        try {
            JsonNode errorNode = objectMapper.readTree(errorBody);
            String errorType = errorNode.path("ERROR_TYPE").asText("");
            if ("Validation Error".equals(errorType)) {
                JsonNode errorReasonArray = errorNode.path("ERROR_REASON");
                if (errorReasonArray.isArray() && errorReasonArray.size() > 0) {
                    String msg = errorReasonArray.get(0).path("msg").asText("IDD Internal Server Error");
                    return msg;
                }
            } else if ("RunTime Error".equals(errorType)) {
                String errorReason = errorNode.path("ERROR_REASON").asText("IDD Internal Server Error");
                return errorReason;
            }
            return "IDD Internal Server Error";
        } catch (Exception e) {
            logToKibana("Error Parsing", requestId, "ERROR", "[UserListService.extractErrorReason] Failed to parse error body: " + e.getMessage());
            try {
                emailService.sendMail("Error Parsing Failure", requestId, "Failed to parse error body: " + e.getMessage());
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.extractErrorReason] Failed to send error parsing email: " + mailEx.getMessage());
            }
            return "IDD Internal Server Error";
        }
    }

    private String formatErrorResponse(String code, String requestId, String errorReason, String status) {
        long startTime = System.nanoTime();
        logToKibana("Error Response Formatting", requestId, "INFO", "[UserListService.formatErrorResponse] Starting error response formatting");
        try {
            ErrorResponse errorResponse = new ErrorResponse(code, requestId, errorReason, status);
            String responseJson = objectMapper.writeValueAsString(errorResponse);
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Error Response Formatting", requestId, "SUCCESS", "[UserListService.formatErrorResponse] Formatted error response, size: " + responseJson.length() + " bytes in " + durationMs + " ms");
            return responseJson;
        } catch (Exception e) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Error Response Formatting", requestId, "ERROR", "[UserListService.formatErrorResponse] Failed to format error response: " + e.getMessage());
            try {
                emailService.sendMail("Error Response Formatting Failure", requestId, "Failed to format error response: " + e.getMessage());
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.formatErrorResponse] Failed to send error response formatting email: " + mailEx.getMessage());
            }
            return "{\"code\":\"500\",\"requestId\":\"" + requestId + "\",\"errorReason\":\"IDD Internal Server Error\",\"status\":\"Failure\"}";
        }
    }

    private ExternalUserListRequestDTO mapToExternalRequest(UserRequestDTO request) {
        long startTime = System.nanoTime();
        String requestId = request.getRequestId() != null ? request.getRequestId() : UUID.randomUUID().toString();
        logToKibana("Request Mapping", requestId, "INFO", "[UserListService.mapToExternalRequest] Starting request mapping");
        ExternalUserListRequestDTO externalRequest = new ExternalUserListRequestDTO();

        externalRequest.setRequestId(requestId);
        externalRequest.setOffset(0);
        externalRequest.setLimit(String.valueOf(iddDefaultExtractSize));

        try {
            externalRequest.setOrganizationNum(Integer.parseInt(request.getOrganisationNum()));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid organization number: " + request.getOrganisationNum());
        }
        externalRequest.setInternalUserLogin(request.getInternalUserLogin());
        externalRequest.setExternalUserLogin(request.getExternalUserLogin());
        externalRequest.setIsCsr(request.getIsCSR());
        externalRequest.setBbpLoginId(request.getBbpLoginId());
        externalRequest.setLanguage(request.getLanguage());

        long durationMs = (System.nanoTime() - startTime) / 1_000_000;
        logToKibana("Request Mapping", requestId, "SUCCESS", "[UserListService.mapToExternalRequest] Request mapped in " + durationMs + " ms");
        return externalRequest;
    }

    private ExternalApiResponse callExternalApi(String token, ExternalUserListRequestDTO request, String requestId, boolean isInitialCall) {
        long startTime = System.nanoTime();
        String callType = isInitialCall ? "Initial" : "Subsequent";
        logToKibana("IDD API Call", requestId, "INFO", "[UserListService.callExternalApi] Starting " + callType + " external API call: " + externalApiUrl);
        try {
            String requestJson = objectMapper.writeValueAsString(request);
            logToKibana("IDD Request", requestId, "INFO", "[UserListService.callExternalApi] " + callType + " Request JSON: " + requestJson);
        } catch (Exception e) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("IDD Request Serialization", requestId, "ERROR", "[UserListService.callExternalApi] Failed to serialize " + callType + " request in " + durationMs + " ms: " + e.getMessage());
            try {
                emailService.sendMail("IDD Request Serialization Failure", requestId, "Failed to serialize " + callType + " request: " + e.getMessage());
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.callExternalApi] Failed to send serialization error email for " + callType + " call: " + mailEx.getMessage());
            }
            throw new RuntimeException("Failed to serialize " + callType + " request: " + e.getMessage(), e);
        }

        ExternalApiResponse response = webClient.post()
                .uri(externalApiUrl)
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .header(HttpHeaders.AUTHORIZATION, "Bearer " + token)
                .bodyValue(request)
                .exchangeToMono(clientResponse -> {
                    return clientResponse.bodyToMono(String.class)
                            .flatMap(rawBody -> {
                                logToKibana("IDD API Raw Response", requestId, "INFO", "[UserListService.callExternalApi] " + callType + " Raw Response: " + rawBody);
                                if (clientResponse.statusCode().isError()) {
                                    return Mono.error(new RuntimeException(
                                            "External API error: Status " + clientResponse.statusCode().value() + ", Body: " + rawBody));
                                } else {
                                    try {
                                        ExternalApiResponse apiResponse = objectMapper.readValue(rawBody, ExternalApiResponse.class);
                                        apiResponse.setHeaders(clientResponse.headers().asHttpHeaders());
                                        return Mono.just(apiResponse);
                                    } catch (Exception e) {
                                        logToKibana("IDD Response Deserialization", requestId, "ERROR", "[UserListService.callExternalApi] Failed to deserialize " + callType + " response: " + e.getMessage());
                                        try {
                                            emailService.sendMail("IDD Response Deserialization Failure", requestId, "Failed to deserialize " + callType + " response: " + e.getMessage());
                                        } catch (Exception mailEx) {
                                            logToKibana("Mail Error", requestId, "ERROR", "[UserListService.callExternalApi] Failed to send deserialization error email for " + callType + " call: " + mailEx.getMessage());
                                        }
                                        return Mono.error(new RuntimeException("Failed to deserialize " + callType + " response: " + e.getMessage(), e));
                                    }
                                }
                            });
                })
                .block();

        long durationMs = (System.nanoTime() - startTime) / 1_000_000;
        logToKibana("IDD API Call", requestId, "SUCCESS", "[UserListService.callExternalApi] " + callType + " API call completed in " + durationMs + " ms");
        return response;
    }

    private String fetchTokenFromExternalApi(String requestId) throws Exception {
        long startTime = System.nanoTime();
        logToKibana("Token Fetch", requestId, "INFO", "[UserListService.fetchTokenFromExternalApi] Starting token fetch from: " + tokenApiUrl);
        try {
            String response = webClient.get()
                    .uri(tokenApiUrl)
                    .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                    .header("api_key", tokenApiKey)
                    .header("transactionid", UUID.randomUUID().toString())
                    .header("SourceSystem", "userList")
                    .retrieve()
                    .onStatus(status -> status.isError(), clientResponse ->
                            clientResponse.bodyToMono(String.class)
                                    .flatMap(errorBody -> {
                                        long durationMs = (System.nanoTime() - startTime) / 1_000_000;
                                        logToKibana("Token API Error", requestId, "ERROR", "[UserListService.fetchTokenFromExternalApi] Status: " + clientResponse.statusCode() + ", Body: " + errorBody + " in " + durationMs + " ms");
                                        try {
                                            emailService.sendMail("Token API Call Failure", requestId, "Status: " + clientResponse.statusCode() + ", Body: " + errorBody);
                                        } catch (Exception mailEx) {
                                            logToKibana("Mail Error", requestId, "ERROR", "[UserListService.fetchTokenFromExternalApi] Failed to send token API error email: " + mailEx.getMessage());
                                        }
                                        return Mono.error(new RuntimeException(
                                                "Token API error: Status " + clientResponse.statusCode() + ", Body: " + errorBody));
                                    }))
                    .bodyToMono(String.class)
                    .block();

            String token = objectMapper.readTree(response).path("token").asText();
            if (token == null || token.isEmpty()) {
                long durationMs = (System.nanoTime() - startTime) / 1_000_000;
                logToKibana("Token Validation", requestId, "ERROR", "[UserListService.fetchTokenFromExternalApi] Token is null or empty in " + durationMs + " ms");
                try {
                    emailService.sendMail("Token Validation Failure", requestId, "Token is null or empty");
                } catch (Exception mailEx) {
                    logToKibana("Mail Error", requestId, "ERROR", "[UserListService.fetchTokenFromExternalApi] Failed to send token validation error email: " + mailEx.getMessage());
                }
                throw new RuntimeException("Token is null or empty");
            }
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Token Fetch", requestId, "SUCCESS", "[UserListService.fetchTokenFromExternalApi] Token fetched in " + durationMs + " ms");
            return token;
        } catch (Exception e) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Token Fetch Error", requestId, "ERROR", "[UserListService.fetchTokenFromExternalApi] Failed to fetch token in " + durationMs + " ms: " + e.getMessage());
            throw e;
        }
    }

    private int parseTotalCount(HttpHeaders headers) {
        long startTime = System.nanoTime();
        String requestId = UUID.randomUUID().toString();
        logToKibana("Total Count Parsing", requestId, "INFO", "[UserListService.parseTotalCount] Starting X-Total-Count header parsing");
        List<String> totalCountHeader = headers.get("X-Total-Count");
        if (totalCountHeader == null || totalCountHeader.isEmpty()) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Total Count Parsing", requestId, "WARN", "[UserListService.parseTotalCount] X-Total-Count header missing, defaulting to 0 in " + durationMs + " ms");
            return 0;
        }
        try {
            int totalCount = Integer.parseInt(totalCountHeader.get(0));
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Total Count Parsing", requestId, "SUCCESS", "[UserListService.parseTotalCount] Parsed total count: " + totalCount + " in " + durationMs + " ms");
            return totalCount;
        } catch (NumberFormatException e) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Total Count Parsing", requestId, "ERROR", "[UserListService.parseTotalCount] Invalid X-Total-Count header: " + totalCountHeader.get(0) + " in " + durationMs + " ms");
            try {
                emailService.sendMail("Total Count Parsing Failure", requestId, "Invalid X-Total-Count header: " + totalCountHeader.get(0));
            } catch (Exception mailEx) {
                logToKibana("Mail Error", requestId, "ERROR", "[UserListService.parseTotalCount] Failed to send total count parsing error email: " + mailEx.getMessage());
            }
            return 0;
        }
    }

    private String formatUserResponse(List<UserListItem> userList, String requestId) throws Exception {
        long startTime = System.nanoTime();
        logToKibana("Response Formatting", requestId, "INFO", "[UserListService.formatUserResponse] Starting user response formatting");
        try {
            UserResponseDTO userResponse = new UserResponseDTO();
            userResponse.setRequestId(requestId);

            List<UserItem> users = userList != null ? userList.stream()
                    .map(item -> {
                        UserItem userItem = new UserItem();
                        userItem.setUserId(item.getUserId()); // Pass String directly
                        userItem.setFullName(item.getUserFullName() != null && !item.getUserFullName().isBlank() ? item.getUserFullName() : "");
                        userItem.setTotalNodeCount(item.getTotalNodeCount() != null ? item.getTotalNodeCount() : 0);
                        userItem.setVisibleNodeCount(item.getVisibleNodeCount() != null ? item.getVisibleNodeCount() : 0);
                        return userItem;
                    })
                    .collect(Collectors.toList())
                    : new ArrayList<>();

            userResponse.setUsers(users);
            String responseJson = objectMapper.writeValueAsString(userResponse);
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Response Formatting", requestId, "SUCCESS", "[UserListService.formatUserResponse] Formatted response, size: " + responseJson.length() + " bytes in " + durationMs + " ms");
            return responseJson;
        } catch (Exception e) {
            long durationMs = (System.nanoTime() - startTime) / 1_000_000;
            logToKibana("Response Formatting Error", requestId, "ERROR", "[UserListService.formatUserResponse] Failed to format response in " + durationMs + " ms: " + e.getMessage());
            throw e;
        }
    }
}