package bell.ca.rest.template.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class UserResponseDTO {

    @JsonProperty("requestId")
    private String requestId;

    @JsonProperty("users")
    private List<UserItem> users;
}