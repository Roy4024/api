package bell.ca.rest.template.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import bell.ca.rest.template.dto.UserRequestDTO;
import bell.ca.rest.template.service.UserListService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class UserListController {

    @Autowired
    private UserListService userService;

    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    private void logToKibana(String logType, String requestId, String status, String message) {
        String timestamp = LocalDateTime.now().format(TIMESTAMP_FORMATTER);
        String logMessage = String.format("[%s] %s %s [ID:%s] %s :: %s",
                timestamp,
                status.equals("ERROR") ? "❌" : status.equals("WARN") ? "⚠️" : status.equals("SUCCESS") ? "✅" : "🚀",
                logType,
                requestId,
                status,
                message);
        if (status.equals("ERROR")) {
            log.error(logMessage);
        } else {
            log.info(logMessage);
        }
    }

    @GetMapping(value = "/health", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> healthCheck() {
        String requestId = "HEALTH-CHECK-" + UUID.randomUUID().toString();
        logToKibana("HEALTH_CHECK", requestId, "INFO", "[UserListController.healthCheck] Health check successful");
        return ResponseEntity.ok()
                .header("X-Health-Check", "true")
                .body("{\"status\": \"ok\"}");
    }

    @PostMapping(value = "/getUserList", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> getUserList(
            @RequestHeader(value = "api_key", required = false) String apiKey,
            @Valid @RequestBody UserRequestDTO request) {
        String requestId = request.getRequestId() != null ? request.getRequestId() : UUID.randomUUID().toString();
        logToKibana("API_REQUEST", requestId, "INFO", "[UserListController.getHierarchy] Request received: " + request);

        try {
            UserListService.ServiceResponse serviceResponse = userService.getUserList(request, apiKey, requestId);
            logToKibana("API_RESPONSE", requestId, "SUCCESS", "[UserListController.getUserList] Response sent, size: " + serviceResponse.getResponseBody().length() + " bytes, status: " + serviceResponse.getStatus());
            return ResponseEntity.status(serviceResponse.getStatus())
                    .header("X-Request-Id", requestId)
                    .body(serviceResponse.getResponseBody());
        } catch (Exception e) {
            logToKibana("API_ERROR", requestId, "ERROR", "[UserListController.getUserList] Unexpected error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .header("X-Request-Id", requestId)
                    .body("{\"error\": \"Unexpected server error: " + e.getMessage() + "\", \"code\": \"500\", \"requestId\": \"" + requestId + "\"}");
        }
    }
}