package bell.ca.rest.template.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class UserRequestDTO {
    private String sourceSystem;
    private String requestId;
    private String requestDate;
    private String requestType;
    private String organisationNum;
    private String internalUserLogin;
    private String externalUserLogin;
    private String isCSR;
    private String bbpLoginId;
    private String language;
}
