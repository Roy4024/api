package bell.ca.rest.template.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ExternalUserListRequestDTO {

    @JsonProperty("REQUESTID")
    private String requestId;

    @JsonProperty("OFFSET")
    private Integer offset;

    @JsonProperty("LIMIT")
    private String limit;

    @JsonProperty("ORGANIZATION_NUM")
    private Integer organizationNum;

    @JsonProperty("INTERNAL_USER_LOGIN")
    private String internalUserLogin;

    @JsonProperty("EXTERNAL_USER_LOGIN")
    private String externalUserLogin;

    @JsonProperty("IS_CSR")
    private String isCsr;

    @JsonProperty("BBP_LOGIN_ID")
    private String bbpLoginId;

    @JsonProperty("LANGUAGE")
    private String language;
}